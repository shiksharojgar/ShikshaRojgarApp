# Shiksha Rojgar Android App — Version 1.5.0

यह अपडेट मौजूदा ऐप की संरचना/मौजूदा Quick Access, Websites, Social buttons, Latest Posts, ticker और bottom navigation को बनाए रखते हुए नया **शिक्षा रोजगार चैनल** जोड़ता है। मौजूदा Blogger feed/website हटाई नहीं गई है।

## नया Channel सिस्टम
- Home पर highlighted **📢 शिक्षा रोजगार चैनल** button.
- Channel में posts, category, date, image/PDF links.
- Follow/Following और Firebase से follower count.
- Like count और comments.
- Admin द्वारा global comments ON/OFF.
- Admin द्वारा प्रत्येक post के comments अलग से ON/OFF.
- Admin post delete कर सकता है.
- केवल चुनी हुई post को **📥 Offline** सेव किया जाता है; पूरी वेबसाइट offline नहीं होती.
- Offline post text/image/PDF app के private storage में सेव होते हैं.
- Firebase Cloud Messaging से channel नई post notification.
- Existing Blogger latest-post notification system भी बना रहता है.

## Firebase setup
`app/google-services.json` पहले से रखा गया है। इसमें project `shiksha-rojgar` और Android package `com.shiksharojgar.app` configured है.

### 1) Firebase Console
- Authentication → Sign-in method → Email/Password **और Anonymous** enable करें.
- Firestore Database बनाएं.
- Storage enable करें.

### 2) Rules deploy
Firebase CLI से project root में:
```bash
firebase deploy --only firestore:rules,storage
```

### 3) Functions deploy
```bash
cd firebase/functions
npm install
cd ../..
firebase deploy --only functions
```

### 4) Admin account
Firebase Authentication में अपना Email/Password user बनाएं। फिर service account credentials के साथ:
```bash
cd firebase/admin
GOOGLE_APPLICATION_CREDENTIALS=./service-account.json ADMIN_EMAIL=YOUR_ADMIN_EMAIL node set-admin.js
```
`admin=true` custom claim मिलने के बाद app में logout/login करें। बिना इस claim के कोई user channel post/upload/delete या global comment setting नहीं बदल सकता।

## Build
GitHub Actions workflow Gradle 8.9 और JDK 17 से Debug APK build करता है। Android Studio में project खोलकर:
**Build → Build Bundle(s) / APK(s) → Build APK(s)**

Version: **1.5.0**  
versionCode: **6**

## Permanent Release / Update Setup
See `docs/RELEASE_SIGNING.md`. Future releases must keep `applicationId=com.shiksharojgar.app`, reuse the same release keystore, and increase `versionCode`. The signed release workflow uses GitHub Secrets rather than storing the private key in the repository.

## Hidden Admin
Admin is intentionally not shown as a normal menu/button. Access requires the hidden entry plus Firebase Authentication and the `admin=true` custom claim. Do not hard-code an admin password in the APK.
