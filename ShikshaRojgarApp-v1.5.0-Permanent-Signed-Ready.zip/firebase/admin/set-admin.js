// Run once with a Firebase service-account JSON:
// GOOGLE_APPLICATION_CREDENTIALS=./service-account.json ADMIN_EMAIL=you@example.com node set-admin.js
const admin = require('firebase-admin');
admin.initializeApp();
const email = process.env.ADMIN_EMAIL;
if (!email) throw new Error('ADMIN_EMAIL is required');
(async()=>{
  const user = await admin.auth().getUserByEmail(email);
  await admin.auth().setCustomUserClaims(user.uid, { admin: true });
  console.log(`admin=true set for ${email}. Sign out/in in the app to refresh the token.`);
  process.exit(0);
})().catch(e=>{console.error(e);process.exit(1);});
