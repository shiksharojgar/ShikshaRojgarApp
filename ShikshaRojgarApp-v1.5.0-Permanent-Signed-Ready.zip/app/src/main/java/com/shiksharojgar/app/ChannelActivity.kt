package com.shiksharojgar.app

import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.messaging.FirebaseMessaging
import java.text.SimpleDateFormat
import java.util.*

class ChannelActivity : AppCompatActivity() {
    private lateinit var list: LinearLayout
    private lateinit var followBtn: TextView
    private lateinit var followerCountView: TextView
    private lateinit var commentStatusView: TextView
    private var globalComments = true
    private val posts = mutableListOf<ChannelPost>()
    private val fmt = SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale("hi", "IN"))

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(makeUi())
        ChannelRepository.ensureSignedIn {
            if (!it) Toast.makeText(this, "Channel connect नहीं हो पाया", Toast.LENGTH_SHORT).show()
            else {
                ChannelRepository.isFollowing { following ->
                    updateFollow(following)
                    if (following) FirebaseMessaging.getInstance().subscribeToTopic("all_channel_followers")
                    else FirebaseMessaging.getInstance().unsubscribeFromTopic("all_channel_followers")
                }
                ChannelRepository.config { count, comments ->
                    globalComments = comments
                    followerCountView.text = "👥 $count Followers"
                    commentStatusView.text = if (comments) "💬 Comments ON" else "🔒 Comments OFF"
                    renderPosts()
                }
                ChannelRepository.posts({ p -> posts.clear(); posts.addAll(p); renderPosts() }, {})
            }
        }
    }

    private fun makeUi(): View {
        val root = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setBackgroundColor(Color.rgb(245,248,252)) }
        val head = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(18,20,18,16); background=GradientFactory.gradient("#075985","#0EA5E9") }
        head.addView(TextView(this).apply { text="📢  शिक्षा रोजगार चैनल"; textSize=23f; setTextColor(Color.WHITE); typeface=Typeface.DEFAULT_BOLD })
        followerCountView=TextView(this).apply { text="👥 Followers"; textSize=14f; setTextColor(Color.WHITE); setPadding(0,7,0,2) }
        head.addView(followerCountView)
        val row=LinearLayout(this).apply { gravity=Gravity.CENTER_VERTICAL }
        followBtn=TextView(this).apply { text="FOLLOW"; gravity=Gravity.CENTER; textSize=13f; typeface=Typeface.DEFAULT_BOLD; setTextColor(Color.WHITE); background=GradientFactory.rounded("#16A34A"); setPadding(28,12,28,12); setOnClickListener { toggleFollow() } }
        row.addView(followBtn)
        commentStatusView=TextView(this).apply { text="💬 Comments"; textSize=12f; setTextColor(Color.WHITE); setPadding(14,0,0,0) }
        row.addView(commentStatusView)
        val admin=TextView(this).apply { text="⚙ Admin"; gravity=Gravity.CENTER; textSize=12f; setTextColor(Color.WHITE); setPadding(12,10,12,10); setOnClickListener { startActivity(Intent(this@ChannelActivity, AdminActivity::class.java)) } }
        row.addView(admin, LinearLayout.LayoutParams(-2,-2).apply { gravity=Gravity.RIGHT })
        head.addView(row)
        root.addView(head)
        val scroll=ScrollView(this)
        list=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(10,10,10,20) }
        scroll.addView(list)
        root.addView(scroll, LinearLayout.LayoutParams(-1,0,1f))
        return root
    }

    private fun toggleFollow() {
        ChannelRepository.isFollowing { current -> ChannelRepository.follow(!current) { ok -> if(ok) { updateFollow(!current); if(!current) FirebaseMessaging.getInstance().subscribeToTopic("all_channel_followers") else FirebaseMessaging.getInstance().unsubscribeFromTopic("all_channel_followers"); Toast.makeText(this, if(!current) "Channel follow हो गया" else "Follow हटाया गया", Toast.LENGTH_SHORT).show() } } }
    }
    private fun updateFollow(v:Boolean) { followBtn.text=if(v) "✓ FOLLOWING" else "FOLLOW"; followBtn.background=GradientFactory.rounded(if(v) "#166534" else "#16A34A") }

    private fun renderPosts() {
        if (!::list.isInitialized) return
        list.removeAllViews()
        if (posts.isEmpty()) { list.addView(TextView(this).apply { text="अभी चैनल में कोई पोस्ट नहीं है।"; textSize=16f; setPadding(16,24,16,24) }); return }
        posts.forEach { p -> list.addView(postView(p)) }
    }

    private fun postView(p: ChannelPost): View {
        val box=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; background=GradientFactory.roundedWhite(); setPadding(14,14,14,12); elevation=3f }
        box.addView(TextView(this).apply { text="${p.category}  •  ${if(p.createdAt>0) fmt.format(Date(p.createdAt)) else ""}"; textSize=11f; setTextColor(Color.rgb(14,91,215)) })
        box.addView(TextView(this).apply { text=p.title; textSize=18f; typeface=Typeface.DEFAULT_BOLD; setTextColor(Color.rgb(25,35,50)); setPadding(0,5,0,3) })
        if(p.body.isNotBlank()) box.addView(TextView(this).apply { text=p.body; textSize=14f; setTextColor(Color.DKGRAY); setPadding(0,0,0,8) })
        if(p.imageUrl.isNotBlank()) box.addView(TextView(this).apply { text="🖼️ आदेश की फोटो उपलब्ध है"; textSize=13f; setTextColor(Color.rgb(14,91,215)); setPadding(0,5,0,5); setOnClickListener { open(p.imageUrl) } })
        if(p.fileUrl.isNotBlank()) box.addView(TextView(this).apply { text="📄 ${p.fileName.ifBlank { "PDF/Document" }}  •  OPEN"; textSize=13f; setTextColor(Color.rgb(14,91,215)); setPadding(0,5,0,5); setOnClickListener { open(p.fileUrl) } })
        val actions=LinearLayout(this).apply { gravity=Gravity.CENTER_VERTICAL; setPadding(0,7,0,0) }
        val like=TextView(this).apply { text="👍 ${p.likeCount}"; textSize=13f; setPadding(6,7,12,7); setOnClickListener { ChannelRepository.isLiked(p.id) { liked -> ChannelRepository.like(p.id,!liked) { } } } }
        val comments=TextView(this).apply { text="💬 ${p.commentCount}"; textSize=13f; setPadding(6,7,12,7); setOnClickListener { showComments(p) } }
        val offline=TextView(this).apply { text=if(OfflineStore.isSaved(this@ChannelActivity,p.id)) "✓ Offline" else "📥 Offline"; textSize=13f; setTextColor(Color.rgb(14,91,215)); setPadding(6,7,12,7); setOnClickListener { if(!OfflineStore.isSaved(this@ChannelActivity,p.id)) { text="⏳ Saving…"; ChannelRepository.saveOffline(this@ChannelActivity,p) { ok,err -> runOnUiThread { text=if(ok) "✓ Offline Saved" else "📥 Offline"; Toast.makeText(this@ChannelActivity, if(ok) "आदेश Offline सेव हो गया" else "सेव नहीं हुआ: $err", Toast.LENGTH_SHORT).show() } } } else openOffline(p) } }
        actions.addView(like); actions.addView(comments); actions.addView(offline)
        val share=TextView(this).apply { text="↗ Share"; textSize=13f; setPadding(6,7,6,7); setOnClickListener { startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply { type="text/plain"; putExtra(Intent.EXTRA_TEXT,p.title+"\n"+p.body) },"Share")) } }
        actions.addView(share)
        box.addView(actions)
        box.setOnClickListener { /* keep card itself non-navigating */ }
        return box.apply { (layoutParams as? LinearLayout.LayoutParams)?.setMargins(0,0,0,10) }
    }

    private fun showComments(p:ChannelPost) {
        if(!globalComments || !p.commentsEnabled) { Toast.makeText(this,"इस पोस्ट पर Comments बंद हैं",Toast.LENGTH_SHORT).show(); return }
        val layout=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(8,4,8,4) }
        val input=EditText(this).apply { hint="अपनी टिप्पणी लिखें…" }
        val listBox=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL }
        layout.addView(listBox); layout.addView(input)
        val dialog=AlertDialog.Builder(this).setTitle("💬 Comments").setView(layout).setPositiveButton("Comment",null).setNegativeButton("Close",null).create()
        ChannelRepository.comments(p.id) { cs -> listBox.removeAllViews(); cs.forEach { c -> listBox.addView(TextView(this).apply { text="${c["name"] ?: "उपयोगकर्ता"}: ${c["text"] ?: ""}"; textSize=13f; setPadding(4,5,4,5) }) } }
        dialog.setOnShowListener { dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener { val t=input.text.toString().trim(); if(t.isNotEmpty()) ChannelRepository.addComment(p.id,t) { ok -> if(ok) input.setText("") } } }
        dialog.show()
    }

    private fun open(url:String) { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) }
    private fun openOffline(p:ChannelPost) {
        val f=ChannelRepository.openOffline(this,p)
        if(f==null){ Toast.makeText(this,"Offline फाइल नहीं मिली",Toast.LENGTH_SHORT).show(); return }
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(10,10,10,10)}
        val txt=TextView(this).apply{text=java.io.File(f,"post.txt").takeIf{it.exists()}?.readText()?:(p.title+"\n\n"+p.body);textSize=15f}
        box.addView(txt)
        val image=java.io.File(f,"image.jpg")
        if(image.exists()){ val iv=ImageView(this).apply{setImageBitmap(android.graphics.BitmapFactory.decodeFile(image.absolutePath));adjustViewBounds=true;setPadding(0,10,0,10)};box.addView(iv) }
        val pdf=f.listFiles()?.firstOrNull{it.name.lowercase().endsWith(".pdf")}
        if(pdf!=null) box.addView(Button(this).apply{text="📄 PDF खोलें";setOnClickListener{try{val uri=androidx.core.content.FileProvider.getUriForFile(this@ChannelActivity,"com.shiksharojgar.app.fileprovider",pdf);startActivity(Intent(Intent.ACTION_VIEW).apply{setDataAndType(uri,"application/pdf");addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)})}catch(e:Exception){Toast.makeText(this@ChannelActivity,"PDF खोलने के लिए PDF viewer चाहिए",Toast.LENGTH_LONG).show()}}})
        AlertDialog.Builder(this).setTitle("📥 Offline आदेश").setView(box).setPositiveButton("OK",null).show()
    }
}

object GradientFactory {
    fun gradient(a:String,b:String)=android.graphics.drawable.GradientDrawable(android.graphics.drawable.GradientDrawable.Orientation.TL_BR,intArrayOf(Color.parseColor(a),Color.parseColor(b))).apply{cornerRadius=26f}
    fun rounded(a:String)=android.graphics.drawable.GradientDrawable().apply{setColor(Color.parseColor(a));cornerRadius=26f}
    fun roundedWhite()=android.graphics.drawable.GradientDrawable().apply{setColor(Color.WHITE);cornerRadius=20f}
}
