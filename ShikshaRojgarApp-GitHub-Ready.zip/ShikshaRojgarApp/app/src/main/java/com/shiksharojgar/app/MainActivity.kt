package com.shiksharojgar.app

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.GridLayout
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager

class MainActivity : AppCompatActivity() {
    private lateinit var adapter: PostAdapter
    private var latest = listOf<Post>()

    private val whatsapp = "https://whatsapp.com/channel/0029Vb6GEDZKLaHxODkeHP1a"
    private val telegram = "https://t.me/Shiksha_Rojgar"
    private val facebook = "https://www.facebook.com/share/1EGdKsY3zL/"
    private val youtube = "https://youtube.com/@mp_education_jobs_news"
    private val instagram = "https://www.instagram.com/shiksha_rojgar?igsh=MX"
    private val shiksha = "https://www.shiksharojgar.com/"
    private val vacancy = "https://www.vacancybazaar.in/"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        adapter = PostAdapter(emptyList()) { openInApp(it.url) }
        findViewById<androidx.recyclerview.widget.RecyclerView>(R.id.postsRecycler).apply {
            layoutManager = LinearLayoutManager(this@MainActivity); adapter = this@MainActivity.adapter
        }
        setupQuickCards()
        setupSocials()
        findViewById<TextView>(R.id.refreshButton).setOnClickListener { loadPosts() }
        findViewById<TextView>(R.id.searchButton).setOnClickListener { showSearchHelp() }
        findViewById<TextView>(R.id.notificationButton).setOnClickListener { showNotificationInfo() }
        findViewById<TextView>(R.id.jobsNav).setOnClickListener { openInApp(vacancy) }
        findViewById<TextView>(R.id.updatesNav).setOnClickListener { loadPosts() }
        findViewById<TextView>(R.id.menuNav).setOnClickListener { showMenu() }
        loadPosts()
    }

    private fun card(label: String, emoji: String, action: () -> Unit): TextView = TextView(this).apply {
        text = "$emoji\n$label"; gravity = Gravity.CENTER; textSize = 13f; setTextColor(resources.getColor(R.color.text));
        setBackgroundResource(R.drawable.card_bg); setPadding(6,14,6,14); isClickable=true; isFocusable=true
        setOnClickListener { action() }
        layoutParams = GridLayout.LayoutParams().apply { width=0; height=112; columnSpec=GridLayout.spec(GridLayout.UNDEFINED,1f); setMargins(4,4,4,4) }
    }

    private fun setupQuickCards() {
        val grid = findViewById<GridLayout>(R.id.quickGrid)
        grid.addView(card("Teacher", "👨‍🏫") { openInApp(shiksha) })
        grid.addView(card("Vacancy", "💼") { openInApp(vacancy) })
        grid.addView(card("Result", "🏆") { openInApp("$shiksha/search/label/Result") })
        grid.addView(card("Admit Card", "🎫") { openInApp("$shiksha/search/label/Admit%20Card") })
        grid.addView(card("Student", "👨‍🎓") { openInApp("$shiksha/search/label/Student") })
        grid.addView(card("School", "🏫") { openInApp("$shiksha/search/label/School") })
    }

    private fun social(label: String, emoji: String, url: String): TextView = card(label, emoji) { openExternal(url) }.apply {
        textSize = 13f
    }
    private fun setupSocials() {
        val grid=findViewById<GridLayout>(R.id.socialGrid)
        grid.addView(social("WhatsApp Channel", "🟢", whatsapp))
        grid.addView(social("Telegram", "✈️", telegram))
        grid.addView(social("YouTube", "▶️", youtube))
        grid.addView(social("Facebook", "📘", facebook))
        grid.addView(social("Instagram", "📸", instagram))
        grid.addView(social("Official Website", "🌐", shiksha))
    }

    private fun loadPosts() {
        findViewById<TextView>(R.id.ticker).text = "नई पोस्ट और VacancyBazaar अपडेट लोड हो रहे हैं…"
        FeedLoader.load { posts ->
            latest = posts
            adapter.submit(posts)
            findViewById<TextView>(R.id.ticker).text = posts.firstOrNull()?.let { "${it.source}: ${it.title}" } ?: "अभी अपडेट उपलब्ध नहीं है — Refresh करें"
        }
    }

    private fun openInApp(url: String) { startActivity(Intent(this, WebViewActivity::class.java).putExtra("url", url)) }
    private fun openExternal(url: String) { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) }

    private fun showSearchHelp() {
        val input=android.widget.EditText(this); input.hint="जैसे Teacher, SSC, Result"
        AlertDialog.Builder(this).setTitle("🔍 Search Shiksha Rojgar").setView(input).setPositiveButton("Search") { _, _ ->
            val q=Uri.encode(input.text.toString()); if(q.isNotBlank()) openInApp("$shiksha/search?q=$q")
        }.setNegativeButton("Cancel", null).show()
    }
    private fun showNotificationInfo() {
        AlertDialog.Builder(this).setTitle("🔔 Notifications").setMessage("Firebase Cloud Messaging जोड़ने के बाद नई भर्ती, Result, Admit Card और Teacher Updates के लिए सीधे मोबाइल notification भेजे जा सकेंगे।\n\nअभी ऐप हर बार खुलने पर दोनों websites से latest posts पढ़ता है।").setPositiveButton("OK", null).show()
    }
    private fun showMenu() {
        val items=arrayOf("👨‍🏫 Teacher","👨‍🎓 Student","🏫 School","💼 VacancyBazaar","🌐 Shiksha Rojgar","▶️ YouTube","🟢 WhatsApp","✈️ Telegram","📘 Facebook","📸 Instagram")
        AlertDialog.Builder(this).setTitle("☰ Shiksha Rojgar Menu").setItems(items) { _, which -> when(which) {
            0,1,2,4 -> openInApp(shiksha); 3 -> openInApp(vacancy); 5 -> openExternal(youtube); 6 -> openExternal(whatsapp); 7 -> openExternal(telegram); 8 -> openExternal(facebook); 9 -> openExternal(instagram)
        }}.show()
    }
}
