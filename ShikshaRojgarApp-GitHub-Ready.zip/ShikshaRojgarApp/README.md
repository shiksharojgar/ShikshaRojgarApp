# Shiksha Rojgar Android App

GitHub-ready starter project for **Shiksha Rojgar + VacancyBazaar.in**.

## Included now
- Shiksha Rojgar logo on the app icon/header and inside the app
- Compact Teacher, Vacancy, Result, Admit Card, Student and School buttons
- Live RSS/Atom feed reading from both sites on app open/refresh
- Combined Latest Posts feed
- In-app WebView for opening a post/site
- Direct buttons for WhatsApp, Telegram, YouTube, Facebook and Instagram
- Search shortcut, refresh, menu and bottom navigation
- GitHub Actions workflow that builds a debug APK

## Live feed URLs
- Shiksha Rojgar: https://www.shiksharojgar.com/feeds/posts/default?alt=rss&max-results=12
- VacancyBazaar: https://www.vacancybazaar.in/feeds/posts/default?alt=rss&max-results=12

The current Shiksha Rojgar website is Blogger-based, so the feed approach is appropriate for live post retrieval. If VacancyBazaar uses another CMS/feed, replace the feed URL in `FeedLoader.kt` with its public RSS/Atom/API endpoint.

## Important: instant push notifications
Reading feeds makes new posts appear when the app opens/refreshes. **Instant notifications while the app is closed require Firebase Cloud Messaging plus a server-side trigger.**

A starter Firebase scheduled function is included in `/firebase/functions/index.js`. It checks both feeds every 15 minutes and sends a topic notification when a new post is detected.

### Firebase setup
1. Create a Firebase project.
2. Add Android app with package name `com.shiksharojgar.app`.
3. Download `google-services.json` and put it in `app/`.
4. Add Firebase Messaging dependencies/plugin to `app/build.gradle.kts` as shown in `firebase/ANDROID_FIREBASE_SNIPPET.md`.
5. Add the Firebase Messaging service from the same guide.
6. Subscribe the app to topic `all_updates`.
7. In Firebase console create notification channel id `shiksha_updates` conceptually; the Android service creates it.
8. Deploy the scheduled function from `/firebase` after creating `.firebaserc`.

## GitHub upload
Create a new empty repository on GitHub, then from this folder:

```bash
git init
git add .
git commit -m "Initial Shiksha Rojgar app"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/YOUR_REPO.git
git push -u origin main
```

Then open GitHub -> **Actions** -> **Build Shiksha Rojgar APK** -> **Run workflow**.

## App links/social links configured
- WhatsApp: https://whatsapp.com/channel/0029Vb6GEDZKLaHxODkeHP1a
- Telegram: https://t.me/Shiksha_Rojgar
- Facebook: https://www.facebook.com/share/1EGdKsY3zL/
- YouTube: https://youtube.com/@mp_education_jobs_news
- Instagram: https://www.instagram.com/shiksha_rojgar?igsh=MX
- Shiksha Rojgar: https://www.shiksharojgar.com/
- VacancyBazaar: https://www.vacancybazaar.in/
