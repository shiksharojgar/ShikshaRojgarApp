package com.shiksharojgar.app

import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.animation.Animation
import android.view.animation.TranslateAnimation
import android.widget.GridLayout
import android.widget.TextView
import android.widget.ImageView
import android.widget.LinearLayout
import androidx.appcompat.app.AlertDialog
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager

class MainActivity : AppCompatActivity() {
    private lateinit var adapter: PostAdapter
    private val shiksha = "https://www.shiksharojgar.com/"
    private val vacancy = "https://www.vacancybazaar.in/"
    private val whatsapp = "https://www.whatsapp.com/channel/0029Vb6GEDZKLaHxODkeHP1a"
    private val telegram = "https://t.me/Shiksha_Rojgar"
    private val youtube = "https://youtube.com/@mp_education_jobs_news"
    private val facebook = "https://www.facebook.com/share/1EGdKsY3zL/"
    private val instagram = "https://www.instagram.com/shiksha_rojgar?igsh=MX"
    private val twitter = "https://x.com/EducationNewsMP?t=pgn4MwOAqY7-WIaoJgX5_A&s=09"
    private val sharechat = "https://sharechat.com/profile/4200901361?d=n"
    private val arattai = "https://aratt.ai/@a_s_chouhan"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.topBar)) { view, insets ->
            val top = insets.getInsets(WindowInsetsCompat.Type.statusBars()).top
            view.setPadding(view.paddingLeft, top + 6, view.paddingRight, view.paddingBottom)
            insets
        }
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.bottomNav)) { view, insets ->
            val bottom = insets.getInsets(WindowInsetsCompat.Type.navigationBars()).bottom
            view.setPadding(view.paddingLeft, 5, view.paddingRight, bottom + 8)
            insets
        }
        adapter = PostAdapter(emptyList()) { openInApp(it.url) }
        findViewById<androidx.recyclerview.widget.RecyclerView>(R.id.postsRecycler).apply {
            layoutManager = LinearLayoutManager(this@MainActivity)
            adapter = this@MainActivity.adapter
        }
        setupQuickCards()
        setupWebsites()
        setupSocials()
        findViewById<TextView>(R.id.refreshButton).setOnClickListener { loadPosts() }
        findViewById<TextView>(R.id.searchButton).setOnClickListener { showSearchHelp() }
        findViewById<TextView>(R.id.notificationButton).setOnClickListener { loadPosts() }
        findViewById<TextView>(R.id.homeNav).setOnClickListener { window.decorView.findViewById<View>(android.R.id.content).scrollTo(0, 0) }
        findViewById<TextView>(R.id.jobsNav).setOnClickListener { openInApp(vacancy) }
        findViewById<TextView>(R.id.updatesNav).setOnClickListener {
            loadPosts()
            findViewById<android.widget.ScrollView>(R.id.contentScroll).post {
                findViewById<View>(R.id.postsRecycler).requestFocus()
                findViewById<android.widget.ScrollView>(R.id.contentScroll).smoothScrollTo(0, findViewById<View>(R.id.postsRecycler).top)
            }
        }
        findViewById<TextView>(R.id.menuNav).setOnClickListener { showMenu() }
        loadPosts()
    }

    private fun roundedGradient(start: String, end: String): GradientDrawable = GradientDrawable(
        GradientDrawable.Orientation.TL_BR, intArrayOf(Color.parseColor(start), Color.parseColor(end))
    ).apply { cornerRadius = 24f }

    private fun card(label: String, emoji: String, colors: Pair<String,String>, action: () -> Unit): TextView = TextView(this).apply {
        text = "$emoji\n$label"
        gravity = Gravity.CENTER
        textSize = 14f
        setTextColor(Color.WHITE)
        typeface = android.graphics.Typeface.DEFAULT_BOLD
        background = roundedGradient(colors.first, colors.second)
        setPadding(8, 14, 8, 14)
        isClickable = true
        isFocusable = true
        elevation = 5f
        setOnClickListener { action() }
        layoutParams = GridLayout.LayoutParams().apply {
            width = 0; height = 106
            columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f)
            setMargins(5, 5, 5, 5)
        }
    }

    private fun setupQuickCards() {
        val grid = findViewById<GridLayout>(R.id.quickGrid)
        val items = listOf(
            Triple("Teacher", "👨‍🏫", { openInApp("https://www.shiksharojgar.com/2026/03/teacher-govt-employees.html") }),
            Triple("Student", "👨‍🎓", { openInApp("https://www.shiksharojgar.com/2026/03/College%20%20University%20Students.html") }),
            Triple("School", "🏫", { openInApp("https://www.shiksharojgar.com/2026/03/school-students-1-12-section-page.html") }),
            Triple("Vacancy", "💼", { openInApp("https://www.shiksharojgar.com/2026/03/latest-jobs-page.html") }),
            Triple("Admit Card", "🎫", { openInApp("https://www.shiksharojgar.com/2026/01/admit-card-download-zone.html") }),
            Triple("Result", "🏆", { openInApp("https://www.shiksharojgar.com/2026/03/results.html") })
        )
        val colors = listOf("#0D5BD7" to "#18A0FB", "#7C3AED" to "#EC4899", "#059669" to "#14B8A6", "#F97316" to "#EF4444", "#D97706" to "#FACC15", "#DB2777" to "#7C3AED")
        items.forEachIndexed { i, item -> grid.addView(card(item.first, item.second, colors[i], item.third)) }
    }

    private fun setupWebsites() {
        val grid = findViewById<GridLayout>(R.id.websiteGrid)
        grid.addView(websiteCard("Shiksha Rojgar.com", "🎓", shiksha, "#075985", "#0EA5E9", R.drawable.logo))
        grid.addView(websiteCard("VacancyBazaar.in", "🚀", vacancy, "#E11D48", "#F59E0B", R.drawable.vacancy_logo))
    }

    private fun websiteCard(label: String, emoji: String, url: String, c1: String, c2: String, icon: Int): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
        background = roundedGradient(c1, c2)
        elevation = 6f
        setPadding(10, 10, 10, 10)
        val logoView = ImageView(this@MainActivity).apply {
            setImageResource(icon)
            scaleType = ImageView.ScaleType.CENTER_CROP
            layoutParams = LinearLayout.LayoutParams(48, 48)
        }
        addView(logoView)
        val text = TextView(this@MainActivity).apply {
            this.text = "$emoji  $label"
            gravity = Gravity.CENTER_VERTICAL
            textSize = 14f
            setTextColor(Color.WHITE)
            typeface = android.graphics.Typeface.DEFAULT_BOLD
            setPadding(10, 0, 6, 0)
        }
        addView(text, LinearLayout.LayoutParams(0, 60, 1f))

        val openButton = TextView(this@MainActivity).apply {
            this.text = "OPEN  ↗"
            gravity = Gravity.CENTER
            textSize = 12f
            setTextColor(Color.WHITE)
            typeface = android.graphics.Typeface.DEFAULT_BOLD
            background = GradientDrawable().apply {
                setColor(Color.argb(55, 255, 255, 255))
                cornerRadius = 18f
                setStroke(1, Color.argb(130, 255, 255, 255))
            }
            setPadding(14, 0, 14, 0)
            isClickable = true
            isFocusable = true
            setOnClickListener { openInApp(url) }
        }
        addView(openButton, LinearLayout.LayoutParams(92, 46).apply {
            gravity = Gravity.CENTER_VERTICAL
        })
        setOnClickListener { openInApp(url) }
        layoutParams = GridLayout.LayoutParams().apply { width=0; height=96; columnSpec=GridLayout.spec(GridLayout.UNDEFINED,1f); setMargins(5,5,5,5) }
    }

    private fun social(label: String, emoji: String, url: String, c1: String, c2: String): TextView = card(label, emoji, c1 to c2) { openExternal(url) }

    private fun setupSocials() {
        val grid = findViewById<GridLayout>(R.id.socialGrid)
        val items = listOf(
            Triple("WhatsApp", "🟢", whatsapp) to ("#16A34A" to "#22C55E"),
            Triple("Telegram", "✈️", telegram) to ("#0284C7" to "#38BDF8"),
            Triple("YouTube", "▶️", youtube) to ("#DC2626" to "#F43F5E"),
            Triple("Facebook", "🔵", facebook) to ("#2563EB" to "#60A5FA"),
            Triple("Instagram", "📸", instagram) to ("#F97316" to "#A855F7"),
            Triple("Twitter / X", "𝕏", twitter) to ("#111827" to "#374151"),
            Triple("ShareChat", "💬", sharechat) to ("#F97316" to "#EF4444"),
            Triple("Arattai", "💠", arattai) to ("#4F46E5" to "#06B6D4"),
            Triple("Official Website", "🌐", shiksha) to ("#0284C7" to "#0EA5E9")
        )
        items.forEach { (item, colors) -> grid.addView(social(item.first, item.second, item.third, colors.first, colors.second)) }
    }

    private fun loadPosts() {
        findViewById<TextView>(R.id.ticker).text = "Shiksha Rojgar की नई पोस्ट लोड हो रही हैं…"
        animateTicker()
        FeedLoader.load { posts ->
            adapter.submit(posts)
            val latestFive = posts.take(5)
            val title = if (latestFive.isNotEmpty()) {
                latestFive.mapIndexed { index, post -> "${index + 1}. ${post.title}" }
                    .joinToString("     ✦     ")
            } else {
                "अभी नई पोस्ट नहीं मिली — Refresh करें"
            }
            findViewById<TextView>(R.id.ticker).text = title
            animateTicker()
        }
    }

    private fun animateTicker() {
        val ticker = findViewById<TextView>(R.id.ticker)
        ticker.post {
            ticker.clearAnimation()
            val parentWidth = (ticker.parent as View).width.toFloat().coerceAtLeast(300f)
            val textWidth = ticker.paint.measureText(ticker.text.toString()).coerceAtLeast(parentWidth * .35f)
            val from = parentWidth
            val to = -textWidth
            TranslateAnimation(from, to, 0f, 0f).apply {
                duration = 11000L
                repeatCount = Animation.INFINITE
                repeatMode = Animation.RESTART
                setInterpolator(android.view.animation.LinearInterpolator())
                ticker.startAnimation(this)
            }
        }
    }

    private fun openInApp(url: String) { startActivity(Intent(this, WebViewActivity::class.java).putExtra("url", url)) }
    private fun openExternal(url: String) { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) }

    private fun showSearchHelp() {
        val input = android.widget.EditText(this)
        input.hint = "जैसे Teacher, SSC, Result"
        AlertDialog.Builder(this).setTitle("🔍 Search Shiksha Rojgar").setView(input).setPositiveButton("Search") { _, _ ->
            val query = input.text.toString().trim()
            if (query.isNotEmpty()) openInApp("$shiksha/search?q=${Uri.encode(query)}")
        }.setNegativeButton("Cancel", null).show()
    }

    private fun showMenu() {
        val items = arrayOf("👨‍🏫 Teacher", "👨‍🎓 Student", "🏫 School", "💼 Vacancy", "🎫 Admit Card", "🏆 Result", "🌐 Shiksha Rojgar", "🚀 VacancyBazaar", "🟢 WhatsApp", "✈️ Telegram", "▶️ YouTube", "📸 Instagram")
        AlertDialog.Builder(this).setTitle("☰ Shiksha Rojgar Menu").setItems(items) { _, which -> when(which) {
            0 -> openInApp("https://www.shiksharojgar.com/2026/03/teacher-govt-employees.html")
            1 -> openInApp("https://www.shiksharojgar.com/2026/03/College%20%20University%20Students.html")
            2 -> openInApp("https://www.shiksharojgar.com/2026/03/school-students-1-12-section-page.html")
            3 -> openInApp("https://www.shiksharojgar.com/2026/03/latest-jobs-page.html")
            4 -> openInApp("https://www.shiksharojgar.com/2026/01/admit-card-download-zone.html")
            5 -> openInApp("https://www.shiksharojgar.com/2026/03/results.html")
            7 -> openInApp(vacancy)
            6 -> openInApp(shiksha)
            8 -> openExternal(whatsapp); 9 -> openExternal(telegram); 10 -> openExternal(youtube); 11 -> openExternal(instagram)
        }}.show()
    }
}
