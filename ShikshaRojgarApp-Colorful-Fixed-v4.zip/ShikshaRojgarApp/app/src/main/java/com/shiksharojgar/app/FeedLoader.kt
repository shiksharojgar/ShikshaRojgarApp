package com.shiksharojgar.app

import android.os.Handler
import android.os.Looper
import java.net.URL
import javax.xml.parsers.DocumentBuilderFactory

object FeedLoader {
    private val handler = Handler(Looper.getMainLooper())
    private fun fetch(feedUrl: String, source: String): List<Post> {
        val result = mutableListOf<Post>()
        val doc = DocumentBuilderFactory.newInstance().newDocumentBuilder().parse(URL(feedUrl).openStream())
        val items = doc.getElementsByTagName("item")
        for (i in 0 until minOf(items.length, 12)) {
            val node = items.item(i)
            fun text(tag: String): String = node.childNodes.let { nodes ->
                for (j in 0 until nodes.length) if (nodes.item(j).nodeName == tag) return nodes.item(j).textContent ?: ""
                ""
            }
            val title = text("title").trim()
            val link = text("link").trim()
            val date = text("pubDate").trim()
            if (title.isNotBlank() && link.isNotBlank()) result += Post(title, link, date, source)
        }
        return result
    }

    fun load(callback: (List<Post>) -> Unit) {
        Thread {
            val all = mutableListOf<Post>()
            try { all += fetch("https://www.shiksharojgar.com/feeds/posts/default?alt=rss&max-results=20", "Shiksha Rojgar") } catch (_: Exception) {}
            val sorted = all.sortedByDescending { it.date }.take(20)
            handler.post { callback(sorted) }
        }.start()
    }
}
