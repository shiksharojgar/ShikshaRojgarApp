package com.shiksharojgar.app

import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.FirebaseException
import com.google.firebase.auth.PhoneAuthCredential
import com.google.firebase.auth.PhoneAuthOptions
import com.google.firebase.auth.PhoneAuthProvider
import java.util.concurrent.TimeUnit
import com.google.firebase.firestore.FirebaseFirestore

class AdminActivity : AppCompatActivity() {
    private val auth=FirebaseAuth.getInstance(); private val db=FirebaseFirestore.getInstance()
    private var imageUri:Uri?=null; private var fileUri:Uri?=null
    private lateinit var panel:LinearLayout; private lateinit var globalSwitch:Switch; private lateinit var postsContainer:LinearLayout
    private val pickImage=registerForActivityResult(ActivityResultContracts.GetContent()){ imageUri=it; toast(if(it!=null) "Image चुनी गई" else "") }
    private val pickFile=registerForActivityResult(ActivityResultContracts.OpenDocument()){ fileUri=it; toast(if(it!=null) "PDF/Document चुना गया" else "") }

    override fun onCreate(savedInstanceState:Bundle?) { super.onCreate(savedInstanceState); setContentView(loginUi()) }
    private var phoneVerificationId: String? = null

    private fun loginUi():View {
        val root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;gravity=Gravity.CENTER;setPadding(24,24,24,24)}
        root.addView(TextView(this).apply{text="🔐 Admin Login";textSize=25f;typeface=Typeface.DEFAULT_BOLD;setTextColor(Color.rgb(7,89,133));gravity=Gravity.CENTER})
        root.addView(TextView(this).apply{text="केवल Admin account से Login करें";textSize=13f;gravity=Gravity.CENTER;setPadding(0,6,0,18)})

        val email=EditText(this).apply{hint="Admin Email";inputType=33}
        val pass=EditText(this).apply{hint="Password";inputType=129}
        root.addView(email,LinearLayout.LayoutParams(-1,56))
        root.addView(pass,LinearLayout.LayoutParams(-1,56))
        root.addView(Button(this).apply{text="LOGIN WITH EMAIL";setOnClickListener{
            auth.signInWithEmailAndPassword(email.text.toString().trim(),pass.text.toString()).addOnSuccessListener{checkAdmin()}.addOnFailureListener{toast("Login असफल: ${it.message}")}
        }})

        root.addView(TextView(this).apply{text="या";textSize=13f;gravity=Gravity.CENTER;setPadding(0,10,0,10)})
        val phone=EditText(this).apply{hint="मोबाइल नंबर (+91XXXXXXXXXX)";inputType=3}
        val otp=EditText(this).apply{hint="OTP (6 अंक)";inputType=2;visibility=View.GONE}
        val send=Button(this).apply{text="📱 SEND OTP"}
        val verify=Button(this).apply{text="✓ VERIFY & LOGIN";visibility=View.GONE}
        root.addView(phone,LinearLayout.LayoutParams(-1,56))
        root.addView(send)
        root.addView(otp,LinearLayout.LayoutParams(-1,56))
        root.addView(verify)

        send.setOnClickListener {
            val number=phone.text.toString().trim()
            if(!number.startsWith("+")){ toast("नंबर +91XXXXXXXXXX जैसे लिखें"); return@setOnClickListener }
            send.isEnabled=false
            val options=PhoneAuthOptions.newBuilder(auth)
                .setPhoneNumber(number)
                .setTimeout(60L,TimeUnit.SECONDS)
                .setActivity(this)
                .setCallbacks(object:PhoneAuthProvider.OnVerificationStateChangedCallbacks(){
                    override fun onVerificationCompleted(credential:PhoneAuthCredential){
                        auth.signInWithCredential(credential).addOnSuccessListener{checkAdmin()}
                            .addOnFailureListener{send.isEnabled=true;toast("Phone Login असफल: ${it.message}")}
                    }
                    override fun onVerificationFailed(e: FirebaseException){send.isEnabled=true;toast("OTP नहीं भेजा गया: ${e.message}")}
                    override fun onCodeSent(id:String,token:PhoneAuthProvider.ForceResendingToken){
                        phoneVerificationId=id; otp.visibility=View.VISIBLE; verify.visibility=View.VISIBLE; send.text="OTP भेजा गया"; toast("OTP भेज दिया गया")
                    }
                }).build()
            PhoneAuthProvider.verifyPhoneNumber(options)
        }
        verify.setOnClickListener {
            val id=phoneVerificationId
            val code=otp.text.toString().trim()
            if(id.isNullOrBlank() || code.length<6){toast("6 अंकों का OTP डालें");return@setOnClickListener}
            verify.isEnabled=false
            auth.signInWithCredential(PhoneAuthProvider.getCredential(id,code)).addOnSuccessListener{checkAdmin()}
                .addOnFailureListener{verify.isEnabled=true;toast("OTP गलत है या Login असफल है")}
        }

        root.addView(TextView(this).apply{text="Admin account को Firebase Authentication में Email/Password या Phone से बनाएं। Phone Login के बाद भी admin=true custom claim जरूरी है।";textSize=12f;setPadding(0,18,0,0)})
        return root
    }
    private fun checkAdmin(){ auth.currentUser?.getIdToken(true)?.addOnSuccessListener{ token -> if(token.claims["admin"]==true) showPanel() else {toast("इस account को Admin अधिकार नहीं मिले हैं");auth.signOut()} } }
    private fun showPanel(){
        panel=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(16,16,16,20)}
        val scroll=ScrollView(this);scroll.addView(panel);setContentView(scroll)
        panel.addView(TextView(this).apply{text="⚙ शिक्षा रोजगार Channel Admin";textSize=22f;typeface=Typeface.DEFAULT_BOLD;setTextColor(Color.rgb(7,89,133));setPadding(0,0,0,15)})
        globalSwitch=Switch(this).apply{text="सभी Posts के Comments";textSize=15f}
        panel.addView(globalSwitch)
        db.document("channel_config/main").get().addOnSuccessListener{globalSwitch.isChecked=it.getBoolean("commentsEnabled") ?: true}
        globalSwitch.setOnCheckedChangeListener{_,checked-> db.document("channel_config/main").set(mapOf("commentsEnabled" to checked), com.google.firebase.firestore.SetOptions.merge()) }
        panel.addView(Button(this).apply{text="📢 नई Channel Post";setOnClickListener{newPostDialog()}})
        panel.addView(Button(this).apply{text="🔄 Channel Posts Refresh";setOnClickListener{loadAdminPosts()}})
        postsContainer=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}
        panel.addView(postsContainer)
        loadAdminPosts()
    }
    private fun newPostDialog(){
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(10,10,10,10)}
        val title=EditText(this).apply{hint="पोस्ट शीर्षक"}; val body=EditText(this).apply{hint="विवरण / आदेश का पाठ";minLines=4}; val cat=EditText(this).apply{hint="Category: आदेश/निर्देश"}
        box.addView(title);box.addView(body);box.addView(cat)
        box.addView(Button(this).apply{text="🖼️ Image चुनें";setOnClickListener{pickImage.launch("image/*")}})
        box.addView(Button(this).apply{text="📄 PDF/Document चुनें";setOnClickListener{pickFile.launch(arrayOf("application/pdf","image/*","text/plain"))}})
        val comments=Switch(this).apply{text="इस Post पर Comments ON";isChecked=true};box.addView(comments)
        AlertDialog.Builder(this).setTitle("नई Channel Post").setView(box).setPositiveButton("PUBLISH",null).setNegativeButton("Cancel",null).create().also{d->
            d.setOnShowListener{d.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener{
                if(title.text.toString().trim().isBlank()){toast("Title जरूरी है");return@setOnClickListener}
                d.getButton(AlertDialog.BUTTON_POSITIVE).isEnabled=false
                uploadBoth(title.text.toString().trim(),body.text.toString(),cat.text.toString().trim().ifBlank{"आदेश/निर्देश"},comments.isChecked){ok,msg->d.dismiss();toast(if(ok)"Post Publish हो गई" else "Publish असफल: $msg");loadAdminPosts()}
            }};d.show()}
    }
    private fun uploadBoth(title:String,body:String,cat:String,comments:Boolean,done:(Boolean,String?)->Unit){
        fun create(image:String,file:String){ ChannelRepository.createPost(mapOf("title" to title,"body" to body,"category" to cat,"imageUrl" to image,"fileUrl" to file,"fileName" to (fileUri?.let{displayName(it)} ?: "document.pdf"),"createdAt" to System.currentTimeMillis(),"commentsEnabled" to comments,"likeCount" to 0L,"commentCount" to 0L)){ok,msg->done(ok,msg)} }
        val i=imageUri; val f=fileUri
        if(i!=null) ChannelRepository.upload(i,"images"){url,err-> if(url==null)done(false,err) else if(f!=null)ChannelRepository.upload(f,"documents"){fu,fe->if(fu==null)done(false,fe)else create(url,fu)} else create(url,"")}
        else if(f!=null) ChannelRepository.upload(f,"documents"){fu,fe->if(fu==null)done(false,fe)else create("",fu)} else create("","")
    }
    private fun loadAdminPosts(){
        if(!::panel.isInitialized)return
        postsContainer.removeAllViews()
        ChannelRepository.posts({ps->ps.take(50).forEach{p->addAdminPost(p)}},{})
    }
    private fun addAdminPost(p:ChannelPost){
        val row=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;background=GradientFactory.roundedWhite();setPadding(12,10,12,10)}
        row.addView(TextView(this).apply{text=p.title;textSize=16f;typeface=Typeface.DEFAULT_BOLD})
        row.addView(TextView(this).apply{text="${p.category} • ${p.likeCount} likes • ${p.commentCount} comments";textSize=12f})
        val actions=LinearLayout(this);val sw=Switch(this).apply{text="Comments";isChecked=p.commentsEnabled;setOnCheckedChangeListener{_,v->db.collection("channel_posts").document(p.id).update("commentsEnabled",v)}}
        actions.addView(sw);actions.addView(Button(this).apply{text="DELETE";setOnClickListener{AlertDialog.Builder(this@AdminActivity).setMessage("Post delete करें?").setPositiveButton("Delete"){_,_->ChannelRepository.deletePost(p.id){toast("Deleted")}}.setNegativeButton("Cancel",null).show()}});row.addView(actions);postsContainer.addView(row)
    }
    private fun displayName(uri:Uri):String{var n="document.pdf";contentResolver.query(uri,arrayOf(OpenableColumns.DISPLAY_NAME),null,null,null)?.use{if(it.moveToFirst())n=it.getString(0)};return n}
    private fun toast(s:String){if(s.isNotBlank())Toast.makeText(this,s,Toast.LENGTH_SHORT).show()}
}
