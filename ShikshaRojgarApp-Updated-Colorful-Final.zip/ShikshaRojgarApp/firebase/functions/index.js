const { onSchedule } = require('firebase-functions/v2/scheduler');
const admin = require('firebase-admin');
const { XMLParser } = require('fast-xml-parser');
const crypto = require('crypto');

admin.initializeApp();
const db = admin.firestore();
const messaging = admin.messaging();
const parser = new XMLParser({ ignoreAttributes: false });

const FEEDS = [
  { source: 'Shiksha Rojgar', url: 'https://www.shiksharojgar.com/feeds/posts/default?alt=rss&max-results=5' },
  { source: 'VacancyBazaar', url: 'https://www.vacancybazaar.in/feeds/posts/default?alt=rss&max-results=5' }
];

function normalizeItems(parsed) {
  const channel = parsed?.rss?.channel || {};
  const raw = channel.item || [];
  return Array.isArray(raw) ? raw : [raw];
}
function hashPost(p) {
  return crypto.createHash('sha256').update(`${p.title}|${p.link}|${p.pubDate || ''}`).digest('hex');
}

exports.checkNewPosts = onSchedule({ schedule: 'every 15 minutes', timeZone: 'Asia/Kolkata', region: 'asia-south1' }, async () => {
  for (const feed of FEEDS) {
    try {
      const res = await fetch(feed.url, { headers: { 'User-Agent': 'ShikshaRojgarApp/1.0' } });
      if (!res.ok) continue;
      const xml = await res.text();
      const parsed = parser.parse(xml);
      const items = normalizeItems(parsed).filter(x => x && x.title && x.link);
      if (!items.length) continue;
      const newest = items[0];
      const id = hashPost(newest);
      const ref = db.collection('feed_state').doc(feed.source.replace(/\W/g, '_'));
      const old = await ref.get();
      if (old.exists && old.data().lastId === id) continue;
      await ref.set({ lastId: id, title: newest.title, link: newest.link, checkedAt: admin.firestore.FieldValue.serverTimestamp() });
      if (old.exists) {
        await messaging.send({
          topic: 'all_updates',
          notification: { title: `${feed.source} – नई पोस्ट`, body: newest.title.slice(0, 120) },
          data: { url: newest.link, source: feed.source, type: 'new_post' },
          android: { priority: 'high', notification: { channelId: 'shiksha_updates' } }
        });
      }
    } catch (e) {
      console.error(feed.source, e);
    }
  }
});
