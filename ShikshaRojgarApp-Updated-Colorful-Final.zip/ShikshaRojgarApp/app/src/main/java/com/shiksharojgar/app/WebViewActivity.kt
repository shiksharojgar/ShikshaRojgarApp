package com.shiksharojgar.app

import android.annotation.SuppressLint
import android.os.Bundle
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class WebViewActivity : AppCompatActivity() {
    private lateinit var web: WebView
    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_webview)
        web = findViewById(R.id.web)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.loadsImagesAutomatically = true
        web.settings.setSupportZoom(false)
        web.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean = false
        }
        web.webChromeClient = WebChromeClient()
        findViewById<TextView>(R.id.backButton).setOnClickListener { goBackOrClose() }
        findViewById<TextView>(R.id.homeButton).setOnClickListener { finish() }
        web.loadUrl(intent.getStringExtra("url") ?: "https://www.shiksharojgar.com/")
    }
    private fun goBackOrClose() { if (web.canGoBack()) web.goBack() else finish() }
    @Deprecated("Deprecated in Android API 33")
    override fun onBackPressed() { goBackOrClose() }
}
