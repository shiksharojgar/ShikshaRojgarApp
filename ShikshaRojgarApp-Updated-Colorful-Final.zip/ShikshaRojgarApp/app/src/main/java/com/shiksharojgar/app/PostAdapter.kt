package com.shiksharojgar.app

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class PostAdapter(private var posts: List<Post>, private val onClick: (Post) -> Unit) : RecyclerView.Adapter<PostAdapter.VH>() {
    class VH(v: View): RecyclerView.ViewHolder(v) {
        val source: TextView = v.findViewById(R.id.source)
        val title: TextView = v.findViewById(R.id.title)
        val date: TextView = v.findViewById(R.id.date)
    }
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH = VH(LayoutInflater.from(parent.context).inflate(R.layout.item_post, parent, false))
    override fun onBindViewHolder(holder: VH, position: Int) {
        val p = posts[position]
        holder.source.text = "${p.source}  •  Latest"
        holder.title.text = p.title
        holder.date.text = p.date
        holder.itemView.setOnClickListener { onClick(p) }
    }
    override fun getItemCount() = posts.size
    fun submit(newPosts: List<Post>) { posts = newPosts; notifyDataSetChanged() }
}
