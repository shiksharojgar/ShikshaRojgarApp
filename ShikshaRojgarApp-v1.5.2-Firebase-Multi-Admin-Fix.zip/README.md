# Shiksha Rojgar Android App — Version 1.5.1

यह अपडेट मौजूदा ऐप की संरचना/मौजूदा Quick Access, Websites, Social buttons, Latest Posts, ticker और bottom navigation को बनाए रखते हुए नया **शिक्षा रोजगार चैनल** जोड़ता है। मौजूदा Blogger feed/website हटाई नहीं गई है।

## नया Channel सिस्टम
- Home पर highlighted **📢 शिक्षा रोजगार चैनल** button.
- Channel में posts, category, date, image/PDF links.
- Follow/Following और Firebase से follower count.
- Like count और comments.
- Admin द्वारा global comments ON/OFF.
- Admin द्वारा प्रत्येक post के comments अलग से ON/OFF.
- Admin post delete कर सकता है.
- केवल चुनी हुई post को **📥 Offline** सेव किया जाता है; पूरी वेबसाइट offline नहीं होती.
- Offline post text/image/PDF app के private storage में सेव होते हैं.
- Firebase Cloud Messaging से channel नई post notification.
- Existing Blogger latest-post notification system भी बना रहता है.

## Firebase setup
`app/google-services.json` पहले से रखा गया है। इसमें project `shiksha-rojgar` और Android package `com.shiksharojgar.app` configured है.

### 1) Firebase Console
- Authentication → Sign-in method → Email/Password **और Anonymous** enable करें.
- Firestore Database बनाएं.
- Storage enable करें.

### 2) Rules deploy
Firebase CLI से project root में:
```bash
firebase deploy --only firestore:rules,storage
```

### 3) Functions deploy
```bash
cd firebase/functions
npm install
cd ../..
firebase deploy --only functions
```

### 4) Admin account
Firebase Authentication में अपना Email/Password user बनाएं। फिर service account credentials के साथ:
```bash
cd firebase/admin
GOOGLE_APPLICATION_CREDENTIALS=./service-account.json ADMIN_EMAIL=YOUR_ADMIN_EMAIL node set-admin.js
```
`admin=true` custom claim मिलने के बाद app में logout/login करें। बिना इस claim के कोई user channel post/upload/delete या global comment setting नहीं बदल सकता।

## Build
GitHub Actions workflow Gradle 8.9 और JDK 17 से Debug APK build करता है। Android Studio में project खोलकर:
**Build → Build Bundle(s) / APK(s) → Build APK(s)**

Version: **1.5.1**  
versionCode: **6**

## Permanent Release / Update Setup
See `docs/RELEASE_SIGNING.md`. Future releases must keep `applicationId=com.shiksharojgar.app`, reuse the same release keystore, and increase `versionCode`. The signed release workflow uses GitHub Secrets rather than storing the private key in the repository.

## Hidden Admin
Admin is intentionally not shown as a normal menu/button. Access requires the hidden entry plus Firebase Authentication and the `admin=true` custom claim. Do not hard-code an admin password in the APK.

## v1.5.1 UI refinement
- Channel admin entry is hidden from the normal Channel screen; admin access remains protected by Firebase Auth + `admin=true` claim.
- Channel now has Back, Home and Share controls near the header.
- Follow is a large, colorful button below the Channel header.
- Offline Downloads has a clearly visible OPEN OFFLINE button.
- Main app and WebView have Share controls; latest posts also have Share.
- LIVE ticker animation is slowed to about 30 seconds per pass.

## Channel / Admin setup (v1.5.1 UI-Fixed-v3)

### Channel connection
The Channel screen no longer blocks public posts when Anonymous Authentication is unavailable. Users can read the public channel without login; Follow and Comment require Firebase Authentication.

Enable Firebase Authentication -> Sign-in method -> Anonymous for the simplest follower flow.

### Admin login
Admin entry remains hidden from normal users: on the Main screen tap the Shiksha Rojgar logo 7 times within about 2.5 seconds. AdminActivity then offers:
- Email + password login
- Phone number + OTP login

The signed-in account must have the Firebase custom claim `admin=true`. The claim must be set with the Firebase Admin SDK; it is not accepted from the client.

For phone admin login, enable Firebase Authentication -> Phone, add the production SMS region policy, and add the release SHA-256 certificate fingerprint in Firebase project settings.

### Follower capacity
There is no artificial follower-count cap in the app code. Each follower is stored as its own Firestore document. Actual service quotas, usage limits, SMS limits, storage/bandwidth and billing still apply.

### Channel sharing
Channel sharing now includes:
- `shiksharojgar://channel` — direct app deep link when the app is installed
- `https://www.shiksharojgar.com/app/channel` — web/fallback URL

For verified HTTPS Android App Links, publish `docs/assetlinks.json.example` content as `https://www.shiksharojgar.com/.well-known/assetlinks.json`.

### LIVE ticker
The main LIVE ticker now contains the latest five titles, repeats the full sequence to avoid a blank gap, and scrolls more slowly.


## v1.5.1 Channel Fix v4
- Fixed Firebase Phone Authentication callback type so the Android project compiles with Firebase Auth BOM 34.2.0.
- Kept the public Channel, Follow, Share/deep-link, Admin email/phone login, and permanent signing setup.
- LIVE ticker now repeats a longer sequence to reduce visible empty gaps.


## v1.5.1 Channel Fix v6
- Admin Login UI improved: Email/Password remains the recommended path; Mobile OTP accepts 10-digit Indian numbers or +91 format.
- Phone OTP failures now show the Firebase error code and actionable setup guidance.
- Channel share uses `https://shiksha-rojgar.web.app/channel` as the primary Android App Link and keeps `shiksharojgar://channel` as a secondary custom scheme.
- Firebase Hosting files include `assetlinks.json` and a fallback channel page. Deploy Hosting once from the `firebase/` directory.
- GitHub debug workflow prints the debug signing fingerprints before APK build.
