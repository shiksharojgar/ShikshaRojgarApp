package com.shiksharojgar.app

import android.content.Context
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Environment
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import com.google.firebase.storage.FirebaseStorage
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.util.UUID

object ChannelRepository {
    private val db = FirebaseFirestore.getInstance()
    private val auth = FirebaseAuth.getInstance()
    private val storage = FirebaseStorage.getInstance()

    fun ensureSignedIn(done: (Boolean) -> Unit) {
        if (auth.currentUser != null) { done(true); return }
        auth.signInAnonymously().addOnCompleteListener { done(it.isSuccessful) }
    }

    fun posts(onResult: (List<ChannelPost>) -> Unit, onError: (Exception) -> Unit) {
        db.collection("channel_posts").orderBy("createdAt", Query.Direction.DESCENDING).limit(100)
            .addSnapshotListener { snap, err ->
                if (err != null) { onError(err); return@addSnapshotListener }
                onResult(snap?.documents?.map { d ->
                    ChannelPost(d.id, d.getString("title").orEmpty(), d.getString("body").orEmpty(),
                        d.getString("imageUrl").orEmpty(), d.getString("fileUrl").orEmpty(), d.getString("fileName").orEmpty(),
                        d.getString("category") ?: "आदेश/निर्देश", d.getLong("createdAt") ?: 0L,
                        d.getBoolean("commentsEnabled") ?: true, d.getLong("likeCount") ?: 0L, d.getLong("commentCount") ?: 0L, d.getLong("viewCount") ?: 0L, d.getLong("shareCount") ?: 0L)
                }.orEmpty())
            }
    }

    fun config(onResult: (Long, Boolean) -> Unit) {
        db.document("channel_config/main").addSnapshotListener { d, _ ->
            onResult(d?.getLong("followerCount") ?: 0L, d?.getBoolean("commentsEnabled") ?: true)
        }
    }

    fun follow(follow: Boolean, done: (Boolean) -> Unit) {
        val uid = auth.currentUser?.uid ?: return done(false)
        val ref = db.collection("channel_followers").document(uid)
        val task = if (follow) {
            ref.set(mapOf("uid" to uid, "joinedAt" to System.currentTimeMillis()))
        } else ref.delete()
        task.addOnSuccessListener {
            // Keep the public counter usable even when Cloud Functions are not deployed.
            db.document("channel_config/main").update(
                "followerCount", com.google.firebase.firestore.FieldValue.increment(if (follow) 1 else -1)
            ).addOnCompleteListener { done(true) }
        }.addOnFailureListener { done(false) }
    }

    fun isFollowing(done: (Boolean) -> Unit) {
        val uid = auth.currentUser?.uid ?: return done(false)
        db.collection("channel_followers").document(uid).get().addOnSuccessListener { done(it.exists()) }.addOnFailureListener { done(false) }
    }

    fun like(postId: String, liked: Boolean, done: (Boolean) -> Unit) {
        val uid = auth.currentUser?.uid ?: return done(false)
        val ref = db.collection("channel_likes").document(postId).collection("users").document(uid)
        val task = if (liked) ref.set(mapOf("uid" to uid, "at" to System.currentTimeMillis())) else ref.delete()
        task.addOnSuccessListener {
            db.collection("channel_posts").document(postId).update(
                "likeCount", com.google.firebase.firestore.FieldValue.increment(if (liked) 1 else -1)
            ).addOnCompleteListener {
                db.document("channel_config/main").update("totalLikes", com.google.firebase.firestore.FieldValue.increment(if (liked) 1 else -1))
                done(true)
            }
        }.addOnFailureListener { done(false) }
    }

    fun isLiked(postId: String, done: (Boolean) -> Unit) {
        val uid = auth.currentUser?.uid ?: return done(false)
        db.collection("channel_likes").document(postId).collection("users").document(uid).get()
            .addOnSuccessListener { done(it.exists()) }.addOnFailureListener { done(false) }
    }

    fun comments(postId: String, onResult: (List<Map<String, Any>>) -> Unit) {
        db.collection("channel_posts").document(postId).collection("comments").orderBy("createdAt", Query.Direction.ASCENDING)
            .addSnapshotListener { snap, _ -> onResult(snap?.documents?.map { it.data ?: emptyMap() }.orEmpty()) }
    }

    fun addComment(postId: String, text: String, done: (Boolean) -> Unit) {
        val user = auth.currentUser ?: return done(false)
        db.collection("channel_posts").document(postId).collection("comments").add(
            mapOf("uid" to user.uid, "text" to text, "name" to "ऐप उपयोगकर्ता", "createdAt" to System.currentTimeMillis())
        ).addOnSuccessListener {
            db.collection("channel_posts").document(postId).update(
                "commentCount", com.google.firebase.firestore.FieldValue.increment(1)
            ).addOnCompleteListener {
                db.document("channel_config/main").update("totalComments", com.google.firebase.firestore.FieldValue.increment(1))
                done(true)
            }
        }.addOnFailureListener { done(false) }
    }

    fun upload(uri: Uri, folder: String, done: (String?, String?) -> Unit) {
        val name = "${System.currentTimeMillis()}_${UUID.randomUUID()}"
        val ref = storage.reference.child("channel/$folder/$name")
        ref.putFile(uri)
            .continueWithTask { task ->
                if (!task.isSuccessful) throw (task.exception ?: RuntimeException("Upload failed"))
                ref.downloadUrl
            }
            .addOnSuccessListener { done(it.toString(), null) }
            .addOnFailureListener { e -> done(null, e.message ?: "Storage upload failed") }
    }

    fun createPost(data: Map<String, Any>, done: (Boolean, String?) -> Unit) {
        db.collection("channel_posts").add(data).addOnCompleteListener { done(it.isSuccessful, it.exception?.message) }
    }

    fun deletePost(id: String, done: (Boolean) -> Unit) { db.collection("channel_posts").document(id).delete().addOnCompleteListener { done(it.isSuccessful) } }

    fun saveOffline(context: Context, post: ChannelPost, done: (Boolean, String?) -> Unit) {
        Thread {
            try {
                val dir = File(context.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS), "ShikshaRojgarOffline")
                if (!dir.exists()) dir.mkdirs()
                val folder = File(dir, post.id.ifBlank { System.currentTimeMillis().toString() }); folder.mkdirs()
                File(folder, "post.txt").writeText("${post.title}\n\n${post.body}\n\nश्रेणी: ${post.category}")
                if (post.imageUrl.isNotBlank()) download(post.imageUrl, File(folder, "image.jpg"))
                if (post.fileUrl.isNotBlank()) download(post.fileUrl, File(folder, post.fileName.ifBlank { "document.pdf" }))
                OfflineStore.mark(context, post, folder.absolutePath)
                done(true, null)
            } catch (e: Exception) { done(false, e.message) }
        }.start()
    }

    fun openOffline(context: Context, post: ChannelPost): File? = OfflineStore.path(context, post.id)?.let(::File)

    private fun download(url: String, target: File) {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 20000; c.readTimeout = 30000
        c.inputStream.use { input -> target.outputStream().use { output -> input.copyTo(output) } }
        c.disconnect()
    }
}
