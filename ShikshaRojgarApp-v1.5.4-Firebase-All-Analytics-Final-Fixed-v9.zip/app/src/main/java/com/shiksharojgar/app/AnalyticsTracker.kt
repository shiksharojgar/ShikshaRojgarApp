package com.shiksharojgar.app

import android.content.Context
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore

/** Central place for Firebase Analytics + unique Firestore engagement counters. */
object AnalyticsTracker {
    private const val PREF = "sr_analytics"
    private val db = FirebaseFirestore.getInstance()
    private val auth = FirebaseAuth.getInstance()

    fun appIdentity(context: Context) {
        val uid = auth.currentUser?.uid ?: return
        db.collection("app_installs").document(uid).set(mapOf("uid" to uid, "firstSeenAt" to System.currentTimeMillis()), com.google.firebase.firestore.SetOptions.merge())
        val day = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
        db.collection("app_usage").document(uid).collection("days").document(day).set(mapOf("uid" to uid, "day" to day, "lastSeenAt" to System.currentTimeMillis()), com.google.firebase.firestore.SetOptions.merge())
    }

    fun appOpen(context: Context) {
        // First use is recorded in Firestore; this avoids an optional Analytics SDK dependency.
        val p = context.getSharedPreferences(PREF, Context.MODE_PRIVATE)
        if (!p.getBoolean("first_use_logged", false)) {
            val uid = auth.currentUser?.uid
            if (uid != null) {
                db.collection("app_first_use").document(uid).set(mapOf("uid" to uid, "version" to BuildConfig.VERSION_NAME, "at" to System.currentTimeMillis()), com.google.firebase.firestore.SetOptions.merge())
            }
            p.edit().putBoolean("first_use_logged", true).apply()
        }
    }

    fun event(context: Context, name: String, params: Map<String, String> = emptyMap()) {
        val uid = auth.currentUser?.uid ?: return
        db.collection("app_events").document(uid).collection("events").add(
            mapOf("name" to name, "params" to params, "at" to System.currentTimeMillis())
        )
    }

    fun websiteOpen(context: Context, source: String) = event(context, "website_open", mapOf("source" to source))
    fun appShare(context: Context) = event(context, "app_share")
    fun channelShare(context: Context) = event(context, "channel_share")
    fun offlineDownload(context: Context, postId: String) = event(context, "offline_download", mapOf("post_id" to postId))
    fun channelFollow(context: Context, following: Boolean) = event(context, if (following) "channel_follow" else "channel_unfollow")

    fun uniqueFeedPostView(context: Context, postId: String) {
        event(context, "feed_post_view", mapOf("post_id" to postId))
        uniqueAction("feed_post_views", safeId(postId), context)
    }

    fun uniqueFeedPostShare(context: Context, postId: String) {
        event(context, "feed_post_share", mapOf("post_id" to postId))
        uniqueAction("feed_post_shares", safeId(postId), context)
    }

    fun uniquePostView(context: Context, postId: String) {
        event(context, "post_view", mapOf("post_id" to postId))
        uniqueAction("post_views", safeId(postId), context)
    }

    fun uniquePostShare(context: Context, postId: String) {
        event(context, "post_share", mapOf("post_id" to postId))
        uniqueAction("post_shares", safeId(postId), context)
    }

    private fun safeId(value: String): String = java.util.UUID.nameUUIDFromBytes(value.toByteArray()).toString()

    private fun uniqueAction(collection: String, postId: String, context: Context) {
        val uid = auth.currentUser?.uid ?: return
        val ref = db.collection(collection).document(postId).collection("users").document(uid)
        ref.get().addOnSuccessListener { existing ->
            if (existing.exists()) return@addOnSuccessListener
            ref.set(mapOf("uid" to uid, "at" to System.currentTimeMillis())).addOnSuccessListener {
                val counterField = if (collection == "post_views") "viewCount" else "shareCount"
                db.collection("channel_posts").document(postId).update(counterField, com.google.firebase.firestore.FieldValue.increment(1))
                val totalField = if (collection == "post_views") "totalPostViews" else "totalPostShares"
                db.document("channel_config/main").update(totalField, com.google.firebase.firestore.FieldValue.increment(1))
            }
        }
    }
}
