# Shiksha Rojgar Android App

Updated from the existing ShikshaRojgarApp project.

## Included in this redesign
- Shiksha Rojgar logo used in the app header and Android launcher icon.
- Colorful, elevated long buttons for Teacher, Student, School, Vacancy, Admit Card and Result.
- Shiksha Rojgar.com and VacancyBazaar.in website buttons with their respective logos and OPEN action.
- Colorful long social buttons for WhatsApp, Telegram, YouTube, Facebook, Instagram, X/Twitter, ShareChat, Arattai and Official Website.
- Left-to-right breaking ticker animation at a readable normal speed.
- Latest post cards loaded by the existing FeedLoader.
- Full-screen WebView navigation for website/category pages.
- Visible in-app Back button plus Android system Back handling through WebView history.
- Elevated bottom navigation to avoid overlap with Android system navigation controls.

## Open in Android Studio
Open the **ShikshaRojgarApp** folder (the folder containing `settings.gradle.kts`).

## Build APK
Android Studio: **Build → Build Bundle(s) / APK(s) → Build APK(s)**.

## GitHub upload
Create a repository and upload the **contents of this ShikshaRojgarApp folder** so that `app/`, `build.gradle.kts`, `settings.gradle.kts`, etc. are at the repository root.


## Version 1.5.0 — Install/First-open tracking
- applicationId remains `com.shiksharojgar.app`.
- versionCode is now `6`; versionName is `1.5.0`.
- Firebase Analytics is configured to record app opens/first use in Firebase Analytics.
- The existing Blogger links, WebView, feed loader, download/update flow, UI and social links are unchanged.
- Before building, add the Firebase Android configuration file at `app/google-services.json`. It must belong to the Firebase Android app with package name `com.shiksharojgar.app`.
