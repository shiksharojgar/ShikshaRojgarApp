plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    // Uncomment after adding app/google-services.json:
    // id("com.google.gms.google-services")
}

android {
    namespace = "com.shiksharojgar.app"
    compileSdk = 35

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }

    defaultConfig { applicationId = "com.shiksharojgar.app"; minSdk = 23; targetSdk = 35; versionCode = 2; versionName = "1.1.0" }
}

dependencies {
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("androidx.recyclerview:recyclerview:1.3.2")
    implementation("androidx.swiperefreshlayout:swiperefreshlayout:1.1.0")
}
