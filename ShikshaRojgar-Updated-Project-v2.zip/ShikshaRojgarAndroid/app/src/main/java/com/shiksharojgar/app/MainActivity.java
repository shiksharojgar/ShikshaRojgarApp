package com.shiksharojgar.app;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.os.Bundle;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.view.WindowInsets;
import android.widget.Toast;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private WebView webView;
    private final Handler main = new Handler(Looper.getMainLooper());
    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private static final String FEED_URL = "https://www.shiksharojgar.com/feeds/posts/default?alt=json&max-results=30";
    private static final long REFRESH_MS = 10 * 60 * 1000L;

    @SuppressLint({"SetJavaScriptEnabled", "JavascriptInterface"})
    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        webView = new WebView(this);
        setContentView(webView);

        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setBuiltInZoomControls(false);
        s.setSupportZoom(false);
        s.setLoadsImagesAutomatically(true);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);

        webView.setWebChromeClient(new WebChromeClient());
        webView.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                view.loadUrl(request.getUrl().toString());
                return true;
            }
        });
        webView.addJavascriptInterface(new AndroidBridge(), "Android");

        // Android 15+ uses edge-to-edge by default. Pass the real system
        // navigation-bar height to the HTML so the bottom navigation never
        // sits underneath the phone's 3-button/gesture navigation area.
        webView.setOnApplyWindowInsetsListener((v, insets) -> {
            int bottom;
            if (Build.VERSION.SDK_INT >= 30) {
                bottom = insets.getInsets(WindowInsets.Type.systemBars()).bottom;
            } else {
                bottom = insets.getSystemWindowInsetBottom();
            }
            final int safeBottom = bottom;
            webView.post(() -> webView.evaluateJavascript(
                    "document.documentElement.style.setProperty('--system-bottom','" + safeBottom + "px');", null));
            return insets;
        });

        webView.loadUrl("file:///android_asset/index.html");
        webView.post(() -> webView.requestApplyInsets());
        fetchBlogger();
        main.postDelayed(refreshRunnable, REFRESH_MS);
    }

    private final Runnable refreshRunnable = new Runnable() {
        @Override public void run() { fetchBlogger(); main.postDelayed(this, REFRESH_MS); }
    };

    private void fetchBlogger() {
        executor.execute(() -> {
            HttpURLConnection c = null;
            try {
                URL u = new URL(FEED_URL);
                c = (HttpURLConnection) u.openConnection();
                c.setRequestMethod("GET");
                c.setConnectTimeout(15000);
                c.setReadTimeout(20000);
                c.setRequestProperty("Accept", "application/json");
                c.setRequestProperty("User-Agent", "ShikshaRojgar/1.0 Android");
                int code = c.getResponseCode();
                if (code < 200 || code >= 300) throw new Exception("HTTP " + code);
                BufferedReader r = new BufferedReader(new InputStreamReader(c.getInputStream(), StandardCharsets.UTF_8));
                StringBuilder b = new StringBuilder(); String line;
                while ((line = r.readLine()) != null) b.append(line);
                String quoted = JSONObject.quote(b.toString());
                main.post(() -> webView.evaluateJavascript("window.receiveBloggerJson(" + quoted + ");", null));
            } catch (Exception e) {
                main.post(() -> Toast.makeText(MainActivity.this, "Blogger अपडेट नहीं मिला", Toast.LENGTH_SHORT).show());
            } finally { if (c != null) c.disconnect(); }
        });
    }

    public class AndroidBridge {
        @JavascriptInterface public void refreshBlogger() { fetchBlogger(); }
    }

    @Override public void onBackPressed() {
        if (webView.canGoBack()) webView.goBack(); else super.onBackPressed();
    }
    @Override protected void onDestroy() {
        main.removeCallbacksAndMessages(null);
        executor.shutdownNow();
        if (webView != null) webView.destroy();
        super.onDestroy();
    }
}
