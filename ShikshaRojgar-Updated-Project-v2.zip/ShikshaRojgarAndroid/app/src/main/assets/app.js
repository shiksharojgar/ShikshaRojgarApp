/* Shiksha Rojgar - live Blogger content + category navigation */
const BLOGGER_URL='https://www.shiksharojgar.com';
const POSTS_LIMIT=30;
const AUTO_REFRESH_MS=10*60*1000;

// Official Shiksha Rojgar category/menu pages found on the website.
const CATEGORY_URLS={
  teacher:'https://www.shiksharojgar.com/2026/03/teacher-govt-employees.html',
  student:'https://www.shiksharojgar.com/2026/03/College%20%20University%20Students.html',
  jobs:'https://www.shiksharojgar.com/2026/03/latest-jobs-page.html',
  result:'https://www.shiksharojgar.com/2026/03/results.html',
  admit:'https://www.shiksharojgar.com/2026/01/admit-card-download-zone.html',
  school:'https://www.shiksharojgar.com/2026/03/school-students-1-12-section-page.html'
};

const content={
  home:['Shiksha Rojgar','Education, jobs and exam updates in one place.'],
  teacher:['Teacher','Recruitment, appointments, training and teacher updates.'],
  student:['Student','Study, scholarship, admission and career guidance.'],
  jobs:['Vacancy / Jobs','Latest government and private job updates.'],
  result:['Result','Latest exam results and merit-list information.'],
  admit:['Admit Card','Exam hall tickets and download information.'],
  school:['School','School education, admission, result and academic updates.'],
  study:['Syllabus / Study Material','Syllabus, model papers, notes and study resources.'],
  notice:['Notes / Updates','Important notices, orders and latest updates.'],
  career:['Career Guide','Courses, careers, admissions and employment guidance.'],
  tools:['Useful Tools','Useful online tools for students and job seekers.'],
  more:['More','App information and update options.'],
  all:['All Updates','Latest Shiksha Rojgar posts.']
};

let allPosts=[];
const $=s=>document.querySelector(s);
const escapeHtml=s=>String(s??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]));
const stripHtml=s=>{const d=document.createElement('div');d.innerHTML=s||'';return(d.textContent||d.innerText||'').replace(/\s+/g,' ').trim();};
const formatDate=s=>{if(!s)return '';try{return new Intl.DateTimeFormat('en-IN',{day:'2-digit',month:'short',year:'numeric'}).format(new Date(s));}catch{return '';}};
const feedUrl=()=>`${BLOGGER_URL}/feeds/posts/default?alt=json&max-results=${POSTS_LIMIT}`;
const labelsOf=e=>(e.category||[]).map(c=>(c.term||'').toLowerCase());

function categoryFor(labels,title){
  const s=(labels.join(' ')+' '+title).toLowerCase();
  if(/admit|प्रवेश|hall ticket|हॉल टिकट/.test(s))return'Admit Card';
  if(/result|रिजल्ट|परिणाम/.test(s))return'Result';
  if(/vacancy|job|recruit|भर्ती|नौकरी|रोजगार/.test(s))return'Vacancy';
  if(/school|स्कूल/.test(s))return'School';
  if(/student|विद्यार्थी|छात्र|scholarship|छात्रवृत्ति|admission|प्रवेश/.test(s))return'Student';
  if(/teacher|शिक्षक|अध्यापक/.test(s))return'Teacher';
  if(/exam|परीक्षा|test|tet|ctet|neet|jee|timetable|time table|टाइम टेबल/.test(s))return'Exam';
  return'Update';
}

function parsePosts(json){
  return(json.feed?.entry||[]).map(e=>{
    const title=stripHtml(e.title?.$t||'Untitled post');
    const raw=e.content?.$t||e.summary?.$t||'';
    const href=(e.link||[]).find(l=>l.rel==='alternate')?.href||'#';
    const published=e.published?.$t||e.updated?.$t||'';
    const labels=labelsOf(e);
    return{title,content:stripHtml(raw),html:raw,href,published,labels,category:categoryFor(labels,title),image:e.media$thumbnail?.url||''};
  });
}

function postCard(p){
  return `<article class="post-item" data-category="${escapeHtml(p.category)}" onclick="openPost(${allPosts.indexOf(p)})"><label>${escapeHtml(p.category)}</label><div class="post-main"><b>${escapeHtml(p.title)}</b><small>${escapeHtml(p.content.slice(0,150))}${p.content.length>150?'…':''}</small></div><time>${escapeHtml(formatDate(p.published))}</time></article>`;
}
function renderPosts(posts=allPosts){
  const box=$('#posts');if(!box)return;
  box.innerHTML=posts.length?posts.map(postCard).join(''):'<div class="empty">No latest posts found.</div>';
}
function renderList(posts,target='#filtered'){
  const box=$(target);if(!box)return;
  box.innerHTML=posts.length?posts.map(postCard).join(''):'<p class="hint">No posts are available in this section yet.</p>';
}

function updateTicker(){
  const track=$('#tickerTrack');if(!track)return;
  if(!allPosts.length){track.innerHTML='<span>Latest Shiksha Rojgar updates loading...</span>';return;}
  const items=allPosts.slice(0,8).map(p=>`<span>🔴 ${escapeHtml(p.title)}</span>`).join('');
  track.innerHTML=items+items;
}

function updateStats(){
  const count=k=>allPosts.filter(p=>p.category.toLowerCase().includes(k.toLowerCase())).length;
  const map={jobs:['jobs','Vacancy'],result:['result','Result'],admit:['admit','Admit Card'],school:['school','School'],student:['student','Student']};
  Object.values(map).forEach(([cls,label])=>{const el=document.querySelector(`.card.${cls} small`);if(el)el.textContent=`${count(label)} posts • View`;});
}
function receivePosts(json){
  allPosts=parsePosts(json);renderPosts();updateStats();updateTicker();
  const stamp=$('#lastUpdated');if(stamp)stamp.textContent=`Updated: ${new Date().toLocaleTimeString('en-IN',{hour:'2-digit',minute:'2-digit'})}`;
}

async function loadBloggerPosts(showLoading=true){
  if(window.Android&&window.Android.refreshBlogger){window.Android.refreshBlogger();return true;}
  if(showLoading&&!allPosts.length)$('#posts').innerHTML='<div class="loading">⏳ Loading latest Shiksha Rojgar posts...</div>';
  try{
    const res=await fetch(feedUrl(),{headers:{Accept:'application/json'},cache:'no-store'});
    if(!res.ok)throw new Error(`HTTP ${res.status}`);
    receivePosts(await res.json());return true;
  }catch(err){
    console.error(err);
    if(!allPosts.length)$('#posts').innerHTML='<div class="setup"><b>Latest posts could not be loaded.</b><p>Check internet and try again.</p><button onclick="loadBloggerPosts()">↻ Try Again</button></div>';
    return false;
  }
}
window.receiveBloggerJson=function(raw){try{receivePosts(typeof raw==='string'?JSON.parse(raw):raw);}catch(e){console.error(e);}};

// Open the actual menu page on shiksharojgar.com.
function openCategory(key){
  const url=CATEGORY_URLS[key];
  if(url){window.location.href=url;return;}
  show(key);
}

function openQuick(key){
  show(key);
}

function show(k){
  const x=content[k]||content.home;
  if(k==='home'){
    $('#content').innerHTML='<div class="content-head"><div><h2>Shiksha Rojgar</h2><p>Education, jobs and exam updates in one place.</p></div></div>';
  }else if(k==='more'){
    $('#content').innerHTML='<div class="content-head"><h2>☰ More</h2><button class="refresh" onclick="loadBloggerPosts()">↻</button></div><p>This app reads the public Shiksha Rojgar Blogger feed and refreshes automatically.</p><div class="info-box"><b>Website</b><br>www.shiksharojgar.com<br><br><b>Auto update</b><br>The app checks for new posts approximately every 10 minutes.</div>';
  }else{
    $('#content').innerHTML=`<div class="content-head"><div><h2>${x[0]}</h2><p>${x[1]}</p></div><button class="refresh" onclick="loadBloggerPosts()">↻</button></div><div id="filtered"></div>`;
    const wanted={jobs:'Vacancy',result:'Result',admit:'Admit Card',school:'School',teacher:'Teacher',student:'Student',all:'',study:'Study',notice:'Update',career:'Career',tools:'Tool'}[k];
    let posts=allPosts;
    if(wanted&&k!=='all')posts=allPosts.filter(p=>(p.category+' '+p.title+' '+p.content).toLowerCase().includes(wanted.toLowerCase()));
    renderList(posts);
  }
  window.scrollTo({top:$('#content').offsetTop-20,behavior:'smooth'});
  document.querySelectorAll('nav button').forEach(b=>b.classList.remove('active'));
  const navMap={home:0,jobs:1,school:2,result:3,more:4};if(navMap[k]!=null)document.querySelectorAll('nav button')[navMap[k]]?.classList.add('active');
}

function safeArticleHtml(html){
  const d=document.createElement('div');d.innerHTML=html||'';
  d.querySelectorAll('script,style,iframe,object,embed,form').forEach(n=>n.remove());
  d.querySelectorAll('*').forEach(n=>{[...n.attributes].forEach(a=>{if(a.name.toLowerCase().startsWith('on'))n.removeAttribute(a.name);});});
  d.querySelectorAll('a').forEach(a=>{a.target='_blank';a.rel='noopener noreferrer';});
  d.querySelectorAll('img').forEach(img=>{img.loading='lazy';img.style.maxWidth='100%';img.style.height='auto';});
  return d.innerHTML;
}
function openPost(index){
  const p=allPosts[index];if(!p)return;
  $('#articleTitle').textContent=p.title;$('#articleMeta').textContent=`${p.category} • ${formatDate(p.published)}`;
  $('#articleBody').innerHTML=safeArticleHtml(p.html)||`<p>${escapeHtml(p.content)}</p>`;$('#articleExternal').href=p.href;
  $('#articleModal').classList.add('show');document.body.classList.add('modal-open');
}
function closePost(){$('#articleModal').classList.remove('show');document.body.classList.remove('modal-open');}
function doSearch(){
  const q=$('#search').value.trim().toLowerCase();if(!q){renderPosts();return;}
  const found=allPosts.filter(p=>(p.title+' '+p.content+' '+p.labels.join(' ')).toLowerCase().includes(q));
  $('#posts').innerHTML=found.length?found.map(postCard).join(''):`<div class="empty">No post found for “${escapeHtml(q)}”.</div>`;
}

$('#search')?.addEventListener('keydown',e=>{if(e.key==='Enter')doSearch();});
$('#articleModal')?.addEventListener('click',e=>{if(e.target.id==='articleModal')closePost();});
if('serviceWorker'in navigator)navigator.serviceWorker.register('sw.js');
loadBloggerPosts();
setInterval(()=>loadBloggerPosts(false),AUTO_REFRESH_MS);
